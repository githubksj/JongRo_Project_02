package com.study.kim.project_02

class ListOfEvaluation {
    val name: String = ""
    val eval_content: String =""
}