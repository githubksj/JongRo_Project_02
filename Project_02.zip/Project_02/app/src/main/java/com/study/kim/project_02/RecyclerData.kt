package com.study.kim.project_02

data class RecyclerData(val no:String, val content:String)

