package com.study.kim.project_02

data class RecyclerViewData(val oneLineEval_No:String, val oneLineEval_content:String)

